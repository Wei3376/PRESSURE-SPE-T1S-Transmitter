/**
  I2C1 Generated Example Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    i2c1_master_example.c

  @Summary
    This is the generated driver examples implementation file for the I2C1 driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides implementations for driver APIs for I2C1.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F57Q43
        Driver Version    :  1.0.0
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.31 and above or later
        MPLAB             :  MPLAB X 5.45
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "i2c1_master_example.h"
#include <math.h>
extern void DELAY_milliseconds(uint16_t milliseconds);

typedef struct
{
    size_t len;
    uint8_t *data;
}i2c1_buffer_t;

static i2c1_operations_t rd1RegCompleteHandler(void *ptr);
static i2c1_operations_t rd2RegCompleteHandler(void *ptr);
static i2c1_operations_t wr1RegCompleteHandler(void *ptr);
static i2c1_operations_t wr2RegCompleteHandler(void *ptr);
static i2c1_operations_t rdBlkRegCompleteHandler(void *ptr);


uint8_t I2C1_Read1ByteRegister(i2c1_address_t address, uint8_t reg)
{
    uint8_t returnValue = 0x00;
    
    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetDataCompleteCallback(rd1RegCompleteHandler,&returnValue);
    I2C1_SetBuffer(&reg,1);
    I2C1_SetAddressNackCallback(NULL,NULL); //NACK polling?
    I2C1_MasterWrite();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
    
    return returnValue;
}

uint16_t I2C1_Read2ByteRegister(i2c1_address_t address, uint8_t reg)
{
    uint16_t returnValue =0x00; // returnValue is little endian

    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetDataCompleteCallback(rd2RegCompleteHandler,&returnValue);
    I2C1_SetBuffer(&reg,1);
    I2C1_SetAddressNackCallback(NULL,NULL); //NACK polling?
    I2C1_MasterWrite();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
  
    return (returnValue << 8 | returnValue >> 8);
}

void I2C1_Write1ByteRegister(i2c1_address_t address, uint8_t reg, uint8_t data)
{
    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetDataCompleteCallback(wr1RegCompleteHandler,&data);
    I2C1_SetBuffer(&reg,1);
    I2C1_SetAddressNackCallback(NULL,NULL); //NACK polling?
    I2C1_MasterWrite();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
}

void I2C1_Write2ByteRegister(i2c1_address_t address, uint8_t reg, uint16_t data)
{
    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetDataCompleteCallback(wr2RegCompleteHandler,&data);
    I2C1_SetBuffer(&reg,1);
    I2C1_SetAddressNackCallback(NULL,NULL); //NACK polling?
    I2C1_MasterWrite();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
}

void I2C1_WriteNBytes(i2c1_address_t address, uint8_t* data, size_t len)
{
    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetBuffer(data,len);
    I2C1_SetAddressNackCallback(NULL,NULL); //NACK polling?
    I2C1_MasterWrite();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
}

void I2C1_ReadNBytes(i2c1_address_t address, uint8_t *data, size_t len)
{
    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetBuffer(data,len);
    I2C1_MasterRead();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
}

void I2C1_ReadDataBlock(i2c1_address_t address, uint8_t reg, uint8_t *data, size_t len)
{
    i2c1_buffer_t bufferBlock; // result is little endian
    bufferBlock.data = data;
    bufferBlock.len = len;

    while(!I2C1_Open(address)); // sit here until we get the bus..
    I2C1_SetDataCompleteCallback(rdBlkRegCompleteHandler,&bufferBlock);
    I2C1_SetBuffer(&reg,1);
    I2C1_SetAddressNackCallback(NULL,NULL); //NACK polling?
    I2C1_MasterWrite();
    while(I2C1_BUSY == I2C1_Close()); // sit here until finished.
}

static i2c1_operations_t rd1RegCompleteHandler(void *ptr)
{
    I2C1_SetBuffer(ptr,1);
    I2C1_SetDataCompleteCallback(NULL,NULL);
    return I2C1_RESTART_READ;
}

static i2c1_operations_t rd2RegCompleteHandler(void *ptr)
{
    I2C1_SetBuffer(ptr,2);
    I2C1_SetDataCompleteCallback(NULL,NULL);
    return I2C1_RESTART_READ;
}

static i2c1_operations_t wr1RegCompleteHandler(void *ptr)
{
    I2C1_SetBuffer(ptr,1);
    I2C1_SetDataCompleteCallback(NULL,NULL);
    return I2C1_CONTINUE;
}

static i2c1_operations_t wr2RegCompleteHandler(void *ptr)
{
    I2C1_SetBuffer(ptr,2);
    I2C1_SetDataCompleteCallback(NULL,NULL);
    return I2C1_CONTINUE;
}

static i2c1_operations_t rdBlkRegCompleteHandler(void *ptr)
{
    I2C1_SetBuffer(((i2c1_buffer_t *)ptr)->data,((i2c1_buffer_t*)ptr)->len);
    I2C1_SetDataCompleteCallback(NULL,NULL);
    return I2C1_RESTART_READ;
}

uint8_t     buf[4];
uint8_t cmd=0;//0-PC,1-PR,2-TC,3TR
#define Pread       1
#define Tread       0
void Read_M32(uint8_t add,uint8_t num)
{
    I2C1_ReadNBytes(add,buf,num);
}

uint16_t   Cvalue[7];
uint32_t   Dvalue[3];
int8_t     Qvalue[7];
int8_t     Ptype;
float DT,TEMP;
float OFF,SENS,PRE;
void Read_D56(uint8_t add)
{
    uint8_t cmd_conp=0X48;
    uint8_t cmd_cont=0X58;
    uint8_t cmd_read=0x00;
    switch(cmd)
    {
        case Pread:
            I2C1_WriteNBytes(add,&cmd_read,1);
            I2C1_ReadNBytes(add,buf,3);
            Dvalue[1]= ((uint32_t)buf[0]<<16) | ((uint32_t)buf[1]<<8) | buf[2];
            I2C1_WriteNBytes(add,&cmd_cont,1);
            cmd=0;
            break;
        case Tread:
            I2C1_WriteNBytes(add,&cmd_read,1);
            I2C1_ReadNBytes(add,buf,3);
            Dvalue[2]= ((uint32_t)buf[0]<<16) | ((uint32_t)buf[1]<<8) | buf[2];
            I2C1_WriteNBytes(add,&cmd_conp,1);
            cmd++;
            break;
        default:
            break;
    }
}

void Read_PROM(uint8_t add)
{
    uint8_t pcnt;
    uint8_t cmd_readprom =0xa0;
    uint8_t crc;
    for(pcnt=0;pcnt<7;pcnt++)
    {
        I2C1_WriteNBytes(add,&cmd_readprom,1);
        I2C1_ReadNBytes(add,buf,2);
        Cvalue[pcnt] = (uint16_t)(buf[0]<<8) | buf[1];
        cmd_readprom=cmd_readprom+2;
    }
    crc=(Cvalue[0]>>12);
    if(crc==crc4(Cvalue))    
        RP_OK=1;
    else
        RP_OK=0;
}

void Cal_D56()
{
    uint8_t cc;
    Ptype=(uint8_t)(Cvalue[0]>>5)&0x1f;
    if(Ptype<=8)
    {Qvalue[1]=20;Qvalue[2]=-2;Qvalue[3]=43;Qvalue[4]=21;Qvalue[5]=-8;Qvalue[6]=22;}
    else if(Ptype<=10)
    {Qvalue[1]=17;Qvalue[2]=-5;Qvalue[3]=43;Qvalue[4]=21;Qvalue[5]=-9;Qvalue[6]=23;}
    else if(Ptype<=13)
    {Qvalue[1]=17;Qvalue[2]=-5;Qvalue[3]=42;Qvalue[4]=20;Qvalue[5]=-9;Qvalue[6]=23;}
    else if(Ptype<=23)
    {Qvalue[1]=20;Qvalue[2]=-2;Qvalue[3]=43;Qvalue[4]=21;Qvalue[5]=-8;Qvalue[6]=22;}
    else if(Ptype<=25)
    {Qvalue[1]=17;Qvalue[2]=-5;Qvalue[3]=43;Qvalue[4]=21;Qvalue[5]=-9;Qvalue[6]=23;}
    else if(Ptype<=28)
    {Qvalue[1]=17;Qvalue[2]=-5;Qvalue[3]=42;Qvalue[4]=20;Qvalue[5]=-9;Qvalue[6]=23;}
    else
    {Qvalue[1]=20;Qvalue[2]=-2;Qvalue[3]=43;Qvalue[4]=21;Qvalue[5]=-8;Qvalue[6]=22;}

   DT= (uint64_t)Dvalue[2]-Cvalue[5]/pow(2,Qvalue[5]-1);
   TEMP=(2000+DT*Cvalue[6]/pow(2,Qvalue[6]-1));
   OFF=(uint64_t)Cvalue[2]/pow(2,Qvalue[2]-1)+DT*Cvalue[4]/pow(2,Qvalue[4]-1);
   SENS=(uint64_t)Cvalue[1]/pow(2,Qvalue[1]-1)+Cvalue[3]/pow(2,Qvalue[3]-1)*DT;
   PRE=(Dvalue[1]*SENS-OFF);
}

void Reset_asic(uint8_t add)
{
    uint8_t cmd_reset=0x1e;
    I2C1_WriteNBytes(add,&cmd_reset,1);
}

uint8_t crc4(uint16_t n_prom[]) 	 	 	// n_prom defined as 8x unsigned int (n_prom[8]) 
{ 
    uint8_t cnt;  	 	 	 	 	 	 	// simple counter 
    uint16_t n_rem=0;      // crc remainder unsigned char n_bit; 
    uint8_t n_bit=0;
    
	n_prom[0]=((n_prom[0]) & 0x00FF);  	 	 	// CRC byte is replaced by 0 
 	n_prom[7]=0; 	 	 	 	 	// Subsidiary value, set to 0 
 	for (cnt = 0; cnt < 16; cnt++)   	 	 	// operation is performed on bytes 
 	{  	 	 	 	 	// choose LSB or MSB 
        if (cnt%2==1)  
            n_rem ^= (unsigned short) ((n_prom[cnt>>1]) & 0x00FF);   
        else   
            n_rem ^= (unsigned short) (n_prom[cnt>>1]>>8);   
        for (n_bit = 8; n_bit > 0; n_bit--) 
        { 	
            if (n_rem & (0x8000)) 	
                n_rem = (n_rem << 1) ^ 0x3000; 
            else 	 	 	
                n_rem = (n_rem << 1); 
        } 	
 	} 	
 	n_rem= ((n_rem >> 12) & 0x000F);  	 	 	// final 4-bit remainder is CRC code 
    return ((uint8_t)(n_rem ^ 0x00));
} 	 

void Init_D56()
{
    if(ASIC==0)
    {
        Read_PROM(IS2405);//Read Calue
        if(RP_OK==1)//crc fail           
        {
            Read_D56(IS2405);//Read invalid T and con P
            DELAY_milliseconds(20);
            Read_D56(IS2405);//Read P 
            DELAY_milliseconds(20);
            Read_D56(IS2405);//Read T 
        }
        else
        { 
        //    PRINT("CRC Fail\r\n");
        }
    }
}
