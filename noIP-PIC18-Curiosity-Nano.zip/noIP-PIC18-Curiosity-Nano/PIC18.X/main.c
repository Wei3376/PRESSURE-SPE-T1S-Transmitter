//DOM-IGNORE-BEGIN
/*
Copyright (C) 2023, Microchip Technology Inc., and its subsidiaries. All rights reserved.

The software and documentation is provided by microchip and its contributors
"as is" and any express, implied or statutory warranties, including, but not
limited to, the implied warranties of merchantability, fitness for a particular
purpose and non-infringement of third party intellectual property rights are
disclaimed to the fullest extent permitted by law. In no event shall microchip
or its contributors be liable for any direct, indirect, incidental, special,
exemplary, or consequential damages (including, but not limited to, procurement
of substitute goods or services; loss of use, data, or profits; or business
interruption) however caused and on any theory of liability, whether in contract,
strict liability, or tort (including negligence or otherwise) arising in any way
out of the use of the software and documentation, even if advised of the
possibility of such damage.

Except as expressly permitted hereunder and subject to the applicable license terms
for any third-party software incorporated in the software and any applicable open
source software license terms, no license or other rights, whether express or
implied, are granted under any patent or other intellectual property rights of
Microchip or any third party.
*/
//DOM-IGNORE-END
/*******************************************************************************
  main-loop for OpenAlliance TC6 10BASE-T1S MACPHY via SPI protocol

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    The main file

  Description:
    This files contains the main-loop driving the initialization and the cyclic
    tasks
*******************************************************************************/

/**************************************************************************************************/
/******                    SET YOUR SERIAL TERMINAL BAUDRATE TO 115200                    *********/
/**************************************************************************************************/

#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include "mcc_generated_files/mcc.h"
#include "systick.h"
#include "tc6-noip.h"
#include "DMASPItransfer.h"
#include "mcc_generated_files/examples/i2c1_master_example.h"

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                          USER ADJUSTABLE                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
#define HARDWARE            0X10        //TE-1.0
#define FIRMWARE            0X10        //TE-1.0
#define FIRMWARE_VERSION            "V3.0.0"

#define BOARD_INSTANCE              (3)
#define T1S_PLCA_ENABLE             (true)
#define T1S_PLCA_NODE_ID            (BOARD_INSTANCE + 1)
#define T1S_PLCA_NODE_COUNT         (8)
#define T1S_PLCA_BURST_COUNT        (0)
#define T1S_PLCA_BURST_TIMER        (0x80)
#define MAC_PROMISCUOUS_MODE        (false)
#define MAC_TX_CUT_THROUGH          (false)
#define MAC_RX_CUT_THROUGH          (false)
#define DELAY_LED                   (333)
#define DELAY_DATA                  (100)
#define DELAY_BEACON_CHECK          (1000)
#define DELAY_STAT                  (1000)
#define UDP_PAYLOAD_OFFSET          (42)

#define ESC_CLEAR_TERMINAL          "\033[2J"
#define ESC_CURSOR_X1Y1             "\033[1;1H"
#define ESC_HIDE_CURSOR             "\033[?25l"
#define ESC_CLEAR_LINE              "\033[2K"
#define ESC_RESETCOLOR              "\033[0m"
#define ESC_GREEN                   "\033[0;32m"
#define ESC_RED                     "\033[0;31m"
#define ESC_YELLOW                  "\033[1;33m"
#define ESC_BLUE                    "\033[0;36m"

#define PRINT(...)                  printf(__VA_ARGS__)
#ifdef DEBUG
#define ASSERT(x)                   __conditional_software_breakpoint(x)
#else
#define ASSERT(x)
#endif

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      DEFINES AND LOCAL VARIABLES                     */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

typedef struct
{
    uint32_t lastLed;
    uint32_t lastData;
    uint32_t lastBeaconCheck;
    uint32_t lastStat;
    uint32_t iperfTx;
    uint32_t iperfRx;
    uint32_t txData;
    uint32_t rxData;
    uint32_t rxErrors;
    uint32_t rxFirstError;
    uint16_t rxLen;
    int8_t idxNoIp;
    bool lastBeaconState;
    bool last_sw;
} MainLocal_t;

static MainLocal_t m;

/* Frame (1512 bytes) */
uint8_t iperf[] = {
    0x00, 0x80, 0xC2, 0x00, 0x01, (T1S_PLCA_NODE_ID + 1u), 0x00, 0x80, /* ..)CI..P */
    0xC2, 0x00, 0x01, T1S_PLCA_NODE_ID, 0x08, 0x00, 0x45, 0x00, /* V.....E. */
    0x00, 0x44, 0xf5, 0x36, 0x00, 0x00, 0x80, 0x11, /* ...6.... */
    0xc4, 0x09, 0xc0, 0xa8, 0x7d, BOARD_INSTANCE, 0xc0, 0xa8, /* ....}... */
    0x7d, 0x80, 0xc6, 0x38, 0x13, 0x89, 0x00, 0x30, /* }..8.... */
    0xc9, 0x7b, 0x00, 0x00, 0x00, 0x08, 0x60, 0xf8, /* .{....`. */
    0x7f, 0x17, 0x00, 0x08, 0xed, 0xe5, 0x00, 0x00, /* ........ */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, /* ........ */
    0x13, 0x89, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* ........ */
    0x00, 0x00, 0xff, 0xff, 0xfc, 0x18, 0x00, 0x00, /* ........ */
    0x2B, 0x84, BOARD_INSTANCE, 0x60, 0x4A, HARDWARE, FIRMWARE, 0x35, /* '.012345 */
    0x04, 0xa7, 0x63, 0x40, 0x30, 0x31, 0x32, 0x33, /* 67890123 */
};
static uint8_t ethRx[sizeof (iperf)];

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      PRIVATE FUNCTION PROTOTYPES                     */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static void SendIperfPacket(void);
static void CheckButton(uint8_t instance, bool newLevel, bool *oldLevel);
static void OnPlcaStatus(int8_t idx, bool success, bool plcaStatus);

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                         PUBLIC FUNCTIONS                             */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

void main(void)
{
    SYSTEM_Initialize();

    SysTick_Init();
    TMR1_StopTimer();
    Init_D56();
    TMR1_StartTimer();

    memset(&m, 0, sizeof(m));
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();
//    TMR1_StopTimer();
    while (!IO_SW0_GetValue()) {
        /* Wait until button gets released */
    }

    PRINT(ESC_CLEAR_TERMINAL \
          ESC_CURSOR_X1Y1    \
          ESC_HIDE_CURSOR    \
          ESC_YELLOW         \
          "=== NoIP PIC18 10Base-T1S Demo " FIRMWARE_VERSION " (" \
          __DATE__ " " __TIME__ ") ===" ESC_RESETCOLOR "\r\n");

    m.idxNoIp = TC6NoIP_Init(T1S_PLCA_ENABLE, T1S_PLCA_NODE_ID, T1S_PLCA_NODE_COUNT,
        T1S_PLCA_BURST_COUNT, T1S_PLCA_BURST_TIMER, MAC_PROMISCUOUS_MODE,
        MAC_TX_CUT_THROUGH, MAC_RX_CUT_THROUGH);

    if (m.idxNoIp < 0) 
    {
        PRINT("Failed to initialize TC6 noIP Driver\r\n");
        while(true) 
        {
            IO_LED0_Toggle();
            SysTick_DelayMS(100);
            if (!IO_SW0_GetValue()) {
                RESET();
            }
        }
    } 
    else 
    {
        while (true)
        {
            uint32_t now;
            TC6NoIP_Service();
            now = SysTick_GetMillis();
            if ((now > 2000u) && (now - m.lastData) > DELAY_DATA) {
                m.lastData = now;
                SendIperfPacket();
            }
            if ((now - m.lastBeaconCheck) > DELAY_BEACON_CHECK) {
                m.lastBeaconCheck = now;
                if (!TC6NoIP_GetPlcaStatus(m.idxNoIp, OnPlcaStatus)) {
                    printf(ESC_RED "GetPlcaStatus failed" ESC_RESETCOLOR "\r\n");
                }
            }
            if ((now - m.lastStat) > DELAY_STAT) {
                m.lastStat = now;
                if (m.txData || m.rxData || m.rxErrors) {
                    PRINT("TX=%ld RX=%ld Err=%ld ErrId=0x%lX\r\n", (m.txData * 8), (m.rxData * 8), m.rxErrors, m.rxFirstError);
                    CLRWDT();
                }
                m.txData = 0;
                m.rxData = 0;
                m.rxErrors = 0;
                m.rxFirstError = 0;
            }
            if ((now - m.lastLed) >= DELAY_LED) {
                m.lastLed = now;
                IO_LED0_Toggle();
            }
            if (!IO_SW0_GetValue()) {
                RESET();
            }
        }
    }
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                  PRIVATE  FUNCTION IMPLEMENTATIONS                   */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

static void SendIperfPacket(void)
{
    uint16_t i = UDP_PAYLOAD_OFFSET;
    iperf[i++] = (m.iperfTx >> 24) & 0xFF;
    iperf[i++] = (m.iperfTx >> 16) & 0xFF;
    iperf[i++] = (m.iperfTx >> 8) & 0xFF;
    iperf[i++] = (m.iperfTx) & 0xFF;
    if (TC6NoIP_SendEthernetPacket(m.idxNoIp, iperf, sizeof(iperf), NULL, NULL)) {
        m.iperfTx++;
        m.txData += sizeof(iperf);
    }
}

static void OnPlcaStatus(int8_t idx, bool success, bool plcaStatus)
{
    if (success) {
        if (plcaStatus != m.lastBeaconState) {
            m.lastBeaconState = plcaStatus;
            if (plcaStatus) {
                PRINT(ESC_GREEN "PLCA Mode active" ESC_RESETCOLOR "\r\n");
            } else {
                PRINT(ESC_RED "CSMA/CD fallback" ESC_RESETCOLOR "\r\n");
            }
        }
        m.lastBeaconState = plcaStatus;
    } else {
        PRINT(ESC_RED "PLCA status register read failed" ESC_RESETCOLOR "\r\n");
    }
}

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
/*                      Callback from NO IP component                   */
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/

void TC6NoIP_CB_OnEthernetReceive(const uint8_t *pRx, uint16_t len)
{
    /* PRINT("RX len=%d\r\n", len); */
}
